<?php
include '../config.php';
header('Content-Type: application/json');


$date = "".date("dd-mm-yyyy");
$data = json_decode(file_get_contents('php://input'), true);
$cust_id = $conn->real_escape_string($data['cust_id']);
$sponser_id = $conn->real_escape_string($data['sponser']);

// Check if username exists
$sql = "SELECT * FROM customer WHERE customer_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param('s', $cust_id);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows > 0) {

    echo json_encode(['status' => 'error', 'message' => 'Username is already taken.']);
} else {
    echo json_encode(['status' => 'success', 'message' => 'Username is available.']);
}

$stmt->close();
$conn->close();
?>
